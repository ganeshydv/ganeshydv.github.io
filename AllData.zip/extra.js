
console.log(2600%1300);