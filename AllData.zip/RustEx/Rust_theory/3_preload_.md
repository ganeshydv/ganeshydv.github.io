
crate : pkg <- module <- function/class

-----------

path sepearor operator:
 :: - used to got from package to module and module to function or class