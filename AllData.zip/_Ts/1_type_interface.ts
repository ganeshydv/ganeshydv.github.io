type isTrue = true | false;
let x: isTrue = true;
console.log(x);

interface User {
  name: string;
  age: number;
}


export {}