
// for in :access index 
let arr=[1,2,3,4];

for(let index in arr){
    console.log(arr[index]);
}

// for of : access elements

for(let ele of arr){
    console.log(ele);
}