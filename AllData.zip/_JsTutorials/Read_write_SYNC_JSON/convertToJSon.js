// let json =require('json');

// data_string = ('{\'1\', \'0\', \'TEST_VIN\', \'1\', \'1512345600000\', ''{\"type\":\"POST\",\"sameCondition\":false,\"vin\":\"TEST_VIN\",'
//                '\"reportTime\":1512345600000,\"categories\":'
//                '[{\"name\":\"Windshield\",\"hasDamage\":true,\"photoUrl\":\"windshield.jpg\",\"comment\":\"big black hole\"},'
//                '{\"name\":\"Side Mirrors-Driver Side\",\"hasDamage\":false,\"photoUrl\":null,\"comment\":\"\"},'
//                '{\"name\":\"Side Mirrors-Passenger Side\",\"hasDamage\":false,\"photoUrl\":null,\"comment\":\"\"},'
//                '{\"name\":\"Tires-Front Driver Side\",\"hasDamage\":false,\"photoUrl\":null,\"comment\":\"\"},'
//                '{\"name\":\"Tires-Rear Driver Side\",\"hasDamage\":false,\"photoUrl\":null,\"comment\":\"\"},'
//                '{\"name\":\"Tires-Front Passenger Side\",\"hasDamage\":false,\"photoUrl\":null,\"comment\":\"\"},'
//                '{\"name\":\"Tires-Rear Passenger Side\",\"hasDamage\":false,\"photoUrl\":null,\"comment\":\"\"},'
//                '{\"name\":\"Body Damage-Front Side\",\"hasDamage\":false,\"photoUrl\":null,\"comment\":\"\"},'
//                '{\"name\":\"Body Damage-Rear Side\",\"hasDamage\":false,\"photoUrl\":null,\"comment\":\"\"},'
//                '{\"name\":\"Body Damage-Front Driver Side\",\"hasDamage\":false,\"photoUrl\":null,\"comment\":\"\"},'
//                '{\"name\":\"Body Damage-Rear Driver Side\",\"hasDamage\":false,\"photoUrl\":null,\"comment\":\"\"},'
//                '{\"name\":\"Body Damage-Front Passenger Side\",\"hasDamage\":false,\"photoUrl\":null,\"comment\":\"\"},'
//                '{\"name\":\"Body Damage-Rear Passenger Side\",\"hasDamage\":false,\"photoUrl\":null,\"comment\":\"\"},'
//                '{\"name\":\"Fire Extinguisher\",\"hasDamage\":false,\"photoUrl\":null,\"comment\":\"\"},'
//                '{\"name\":\"Lights (Head, Turn, Tail)-Front Driver Side\",\"hasDamage\":false,\"photoUrl\":null,\"comment\":\"\"},'
//                '{\"name\":\"Lights (Head, Turn, Tail)-Rear Driver Side\",\"hasDamage\":false,\"photoUrl\":null,\"comment\":\"\"},'
//                '{\"name\":\"Lights (Head, Turn, Tail)-Front Passenger Side\",\"hasDamage\":false,\"photoUrl\":null,\"comment\":\"\"},'
//                '{\"name\":\"Lights (Head, Turn, Tail)-Rear Passenger Side\",\"hasDamage\":false,\"photoUrl\":null,\"comment\":\"\"},'
//                '{\"name\":\"Wipers\",\"hasDamage\":false,\"photoUrl\":null,\"comment\":\"\"},'
//                '{\"name\":\"Brakes\",\"hasDamage\":false,\"photoUrl\":null,\"comment\":\"\"}],'
//                '\"comment\":\"\",\"version\":\"20171212-1\"}', '2018-01-30 23:53:20',
//                '2018-10-04 23:49:52', '0', '1', None, None, None, None, None, None, None)


// data_string = data_string.replace('\'', '\"')


// data_json = json.loads(data_string)

// print(data_json)
