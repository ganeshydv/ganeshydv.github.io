const personKey="add"
let person={
    name:"tony",
    age:"30",
    [personKey]:""
}
// personKey="add"
console.log(person);