let a=1;
(function(){
    let a=2;
    console.log(a);
}())
console.log(a);