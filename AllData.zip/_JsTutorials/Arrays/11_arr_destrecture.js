
const arr=["stark",20,"tony"]

const [Firstname,age]=arr;

console.log(Firstname,age);