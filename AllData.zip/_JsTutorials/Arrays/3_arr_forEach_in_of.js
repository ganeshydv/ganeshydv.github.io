
const arr=[1,2,3,4];

// for(const ele of arr){
//     console.log(ele);
// }

// arr.forEach((ele,index,arr_whole_array)=>{
//     console.log(ele ,index);
// })

for(let ele in arr){
    console.log(arr[ele]);
}