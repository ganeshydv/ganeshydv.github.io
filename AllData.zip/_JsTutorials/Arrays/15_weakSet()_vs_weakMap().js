

// weakSet() : only store object data as element NOT PREMETIVE value : number,etc
