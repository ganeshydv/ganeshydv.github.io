

// 1

const sum=(a,b)=>a+b;

//2 


const add=(a,b)=>{const result=a+b; return result;}

//3

const greet=()=>{console.log("hello..")}

//4  -- Return Object

const person=(pName,pAge)=>({name:pName,age:pAge})