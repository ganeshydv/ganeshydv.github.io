
// function can be called before definaton it is called hosting in js

sum();

function sum() {
    console.log("sum called");
}