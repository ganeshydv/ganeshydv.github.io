let a=function fun1(){
    console.log("in fun1")
}
module.exports.a=a;
let b=function fun2(){
    console.log("in fun2")
}
module.exports.b=b;
let c=function fun3(){
    console.log("in fun3")
}
module.exports.c=c;
// module.exports=function fun4(){
//     console.log("in fun4")
// }