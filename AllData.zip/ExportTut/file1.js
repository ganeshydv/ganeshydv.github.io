// import pkg from './file2.js' ;
const funs=require('./file2.js');
import {a,b,c} from "./file2";
// console.log(funs)
// funs.a()
c();